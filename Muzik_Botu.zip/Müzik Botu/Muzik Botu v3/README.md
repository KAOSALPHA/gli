**Alt yapıyı çalmaya kalkışan arkadaşlara söyliyim korona döneminde işim gücüm yok sizinle uğraşırım!**

**Yapımcı ✩ Shelley Hennigᴹᴬᴳ#0761**

**Geliştirici: LoZ 'Be℣™#0590**